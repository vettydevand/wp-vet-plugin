# WP Vet Plugin: Calendario per Appuntamenti Veterinari

WP Vet Plugin è un calendario di appuntamenti flessibile e facile da usare, progettato per studi veterinari ma adattabile a qualsiasi esigenza di pianificazione. Offre un'interfaccia intuitiva basata su FullCalendar per la gestione di eventi.

Questo plugin può funzionare in due modalità: come un tradizionale **plugin di WordPress** o come un'**applicazione web standalone**, senza richiedere un'installazione di WordPress.

## Indice

- [Caratteristiche](#caratteristiche)
- [Modalità di Utilizzo](#modalità-di-utilizzo)
- [Installazione (Plugin WordPress)](#installazione-plugin-wordpress)
- [Installazione (Standalone)](#installazione-standalone)
- [Personalizzazione (Standalone)](#personalizzazione-standalone)
- [Deployment Automatizzato (Infrastructure as Code)](#deployment-automatizzato-infrastructure-as-code)
- [Guida Rapida all'Uso](#guida-rapida-alluso)
- [Contribuire](#contribuire)

## Caratteristiche

- **Visualizzazione Multipla:** Calendario mensile, settimanale e giornaliero.
- **Gestione Eventi Drag & Drop:** Crea, sposta e ridimensiona gli appuntamenti direttamente dal calendario.
- **Modale Intuitiva:** Inserisci, modifica o elimina i dettagli dell'appuntamento con un semplice clic.
- **Backend Leggero:** Utilizza AJAX per le operazioni nel plugin WordPress e un backend PHP con SQLite per la versione standalone.
- **Altamente Personalizzabile:** Configura il percorso del database e personalizza l'aspetto (colori, font, logo) tramite semplici file di configurazione.
- **Indipendente:** La modalità standalone non richiede dipendenze esterne complesse, solo PHP e SQLite.

## Modalità di Utilizzo

1.  **Plugin WordPress:** Si integra perfettamente con la tua installazione WordPress esistente. Ideale per chi ha già un sito e vuole aggiungere funzionalità di calendario.
2.  **Standalone:** Un'applicazione web completa e indipendente. Perfetta per un uso interno o per chi non utilizza WordPress. Richiede un ambiente con PHP e l'estensione SQLite.

---

## Installazione (Plugin WordPress)

Segui questi passaggi per installare il plugin sul tuo sito WordPress.

1.  **Scarica il Plugin:** Scarica l'archivio `.zip` di questo repository.
2.  **Carica su WordPress:**
    - Accedi alla tua bacheca di WordPress.
    - Vai su `Plugin > Aggiungi nuovo`.
    - Clicca su `Carica plugin` in alto.
    - Seleziona il file `.zip` e clicca su `Installa ora`.
3.  **Attiva il Plugin:** Una volta installato, clicca su `Attiva plugin`.
4.  **Fatto!** Il calendario sarà disponibile in una nuova voce di menu nella tua bacheca.

---

## Installazione (Standalone)

Questa modalità non richiede WordPress. È sufficiente un server web con supporto a PHP e SQLite.

### Prerequisiti

- [PHP](https://www.php.net/manual/en/install.php) (versione 7.4 o successiva)
- Estensione [PHP SQLite3](https://www.php.net/manual/en/book.sqlite3.php) (solitamente inclusa nelle installazioni standard di PHP).

### Guida Rapida all'Avvio

1.  **Clona o Scarica il Repository:**
    ```bash
    git clone https://github.com/tuo-utente/wp-vet-plugin.git
    ```
    Oppure scarica e decomprimi lo zip.

2.  **Configurazione Iniziale (Opzionale):**
    Naviga nella cartella `wp-vet-plugin/modern-standalone/`. Qui troverai dei file di configurazione di esempio:
    - `config.php.example`: Per configurare il percorso del database.
    - `theme.json`: Per personalizzare l'aspetto dell'applicazione.
    
    Leggi la sezione [Personalizzazione (Standalone)](#personalizzazione-standalone) per maggiori dettagli.

3.  **Avvia il Server PHP:**
    Apri il terminale, naviga fino alla cartella `modern-standalone` e avvia il server di sviluppo integrato di PHP.
    ```bash
    cd percorso/del/progetto/wp-vet-plugin/modern-standalone/
    php -S localhost:8000
    ```

4.  **Apri il Calendario:**
    Apri il tuo browser e visita [http://localhost:8000](http://localhost:8000). Il database `database.sqlite` verrà creato automaticamente al primo utilizzo nel percorso predefinito o in quello specificato.

---

## Personalizzazione (Standalone)

L'applicazione standalone è progettata per essere facilmente personalizzabile senza modificare il codice sorgente.

### 1. Configurazione del Backend (`config.php`)

Puoi specificare un percorso personalizzato per il file del database SQLite. Questo è utile per salvare i dati in una posizione specifica o per gestire più database.

1.  **Crea il file di configurazione:**
    Nella cartella `modern-standalone/`, rinomina o copia `config.php.example` in `config.php`.

2.  **Modifica il percorso:**
    Apri `config.php` e modifica la costante `DB_PATH` con il percorso assoluto o relativo desiderato.
    ```php
    <?php
    // Esempio: Salva il database in una cartella dati fuori dalla root del web server
    define('DB_PATH', __DIR__ . '/../data/my_clinic_database.sqlite');
    ```

**Importante:** `config.php` è già incluso nel file `.gitignore` per prevenire che le tue configurazioni private vengano inviate a un repository Git.

### 2. Theming e Personalizzazione del Frontend (`theme.json`)

Puoi cambiare l'aspetto dell'applicazione (colori, font, nome e logo) modificando il file `theme.json` che si trova in `modern-standalone/`.

- **`appName`**: Il nome della tua clinica o applicazione, mostrato in alto.
- **`logoUrl`**: Il percorso del tuo logo. Per un risultato ottimale, inserisci il tuo file (es. `logo.png`) nella cartella `assets/` e imposta il valore su `"assets/logo.png"`.
- **`theme.colors`**: Personalizza i colori principali dell'interfaccia. I nomi (`primary`, `success`, `danger`, etc.) si basano sulla nomenclatura standard di framework come Bootstrap. Puoi usare qualsiasi codice colore CSS (es. `#RRGGBB`).
- **`theme.fonts.main`**: Definisci il font principale per l'applicazione.

Se `theme.json` viene rimosso o contiene errori, l'applicazione tornerà a un tema di default per garantire la continuità del servizio.

---

## Deployment Automatizzato (Infrastructure as Code)

Per semplificare e standardizzare il deployment della versione **standalone**, abbiamo preparato alcuni esempi di Infrastructure as Code (IaC). Questi strumenti ti permettono di definire e provisionare l'intera infrastruttura e configurazione del software tramite codice, rendendo il processo più rapido, ripetibile e meno soggetto a errori.

Visita la cartella [`iac/`](./iac) per accedere alle guide e agli esempi per i seguenti strumenti:

- **[Containerizzazione (Docker/Podman)](./iac/containerization):** Il modo più semplice e veloce per eseguire l'applicazione in un ambiente isolato e coerente. Altamente raccomandato per lo sviluppo e la produzione.
- **[cloud-init](./iac/cloud-init):** Ideale per la configurazione iniziale automatica di una macchina virtuale al suo primo avvio. Perfetto per provider cloud come AWS, Google Cloud, DigitalOcean, etc.
- **[Ansible](./iac/ansible):** Uno strumento potente per la gestione della configurazione. Puoi usarlo per configurare un server esistente o per orchestrare deployment complessi.
- **[OpenTofu (Terraform)](./iac/opentofu):** Permette di definire e creare l'intera infrastruttura cloud (VM, reti, firewall) come codice, integrandosi perfettamente con `cloud-init` per un setup completo.

---

## Guida Rapida all'Uso

L'interfaccia del calendario è progettata per essere il più intuitiva possibile.

- **Aggiungere un appuntamento:** Clicca su una data o un orario vuoto. Si aprirà una finestra modale dove potrai inserire i dettagli.
- **Modificare un appuntamento:** Clicca su un appuntamento esistente. La stessa finestra modale ti permetterà di cambiarne i dettagli.
- **Eliminare un appuntamento:** Clicca su un appuntamento e usa il pulsante "Elimina" all'interno della modale.
- **Spostare o Ridimensionare:** Trascina un appuntamento per spostarlo in un'altra data/ora o trascina i suoi bordi per cambiarne la durata.

## Contribuire

I contributi sono benvenuti! Se hai idee, suggerimenti o vuoi correggere un bug, sentiti libero di aprire una issue o una pull request su GitHub.
